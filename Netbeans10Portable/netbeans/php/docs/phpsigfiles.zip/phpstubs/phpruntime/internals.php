<?php



class stdClass {
}

