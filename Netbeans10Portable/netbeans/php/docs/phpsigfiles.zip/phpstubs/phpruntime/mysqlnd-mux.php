<?php



/**
 * Plugin version string, for example, "1.0.0-prototype".
 */
define('MYSQLND_MUX_VERSION', null);

/**
 * Plugin version number, for example, 10000.
 */
define('MYSQLND_MUX_VERSION_ID', null);

