<?php



namespace {

	/**
	 * Get the inclued data
	 * <p>Get the inclued data.</p>
	 * @return array <p>The inclued data.</p>
	 * @link http://php.net/manual/en/function.inclued-get-data.php
	 * @see debug_backtrace(), include
	 * @since PECL inclued >= 0.1.0
	 */
	function inclued_get_data(): array {}

}
